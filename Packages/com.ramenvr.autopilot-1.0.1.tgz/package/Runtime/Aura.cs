// Autopilot with Aura (the window's "Use with Aura"): instead of an agent service of your own, the one the Aura app
// runs on this machine, so runs go through Aura (on your Aura plan) and what the agent learns about each game is kept
// with Aura across your team's machines. Off by default: Autopilot on its own never connects to Aura.
//
// A running agent service says where it listens in Autopilot/<file> in the user settings folder, as the Unreal plugin
// and autopilot/bridge.py name it (%LOCALAPPDATA% on Windows, ~/Library/Application Support on macOS, $XDG_CONFIG_HOME or
// ~/.config elsewhere): brain.json for an Autopilot of your own, aura-brain.json for Aura's.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace Autopilot.Playtest
{
    public static class Aura
    {
        public const string DownloadUrl = "https://www.tryaura.dev/";
        public const string OwnBrainFile = "brain.json";
        public const string AuraBrainFile = "aura-brain.json";

        /// <summary>The user settings folder (as autopilot/bridge.py's brain_file): %LOCALAPPDATA% on Windows,
        /// ~/Library/Application Support on macOS, $XDG_CONFIG_HOME or ~/.config elsewhere.</summary>
        public static string SettingsFolder()
        {
            var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var local = Environment.GetEnvironmentVariable("LOCALAPPDATA");
                return string.IsNullOrEmpty(local) ? Path.Combine(home, "AppData", "Local") : local;
            }
            if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX)) return Path.Combine(home, "Library", "Application Support");
            var xdg = Environment.GetEnvironmentVariable("XDG_CONFIG_HOME");
            return string.IsNullOrEmpty(xdg) ? Path.Combine(home, ".config") : xdg;
        }

        /// <summary>Autopilot's folder in the user settings folder: brain.json, aura-brain.json, preferences.json,
        /// autopilot.env. The folder under Autopilot's name before is moved over the first time (MoveSettings).</summary>
        public static string Folder()
        {
            if (FolderOverride != null) return FolderOverride;
            var settings = SettingsFolder();
            if (!moved)
            {
                moved = true;
                MoveSettings(settings);
            }
            return Path.Combine(settings, FolderName);
        }

        /// <summary>Tests only: another folder in place of the user's Autopilot folder (null: the user's).</summary>
        public static string FolderOverride;

        public const string FolderName = "Autopilot";
        /// <summary>The folder's name before Autopilot (RamenGamer/, its keys in gamer.env as GAMER_*).</summary>
        public const string OldFolderName = "RamenGamer";
        const string OldEnvFile = "gamer.env";
        static readonly Regex OldEnvKey = new Regex(@"^([ \t]*(?:export[ \t]+)?)GAMER_", RegexOptions.Multiline);
        static bool moved;
        // Set while Autopilot is being removed from this computer (Editor/Uninstall.cs): the old-named folder is never
        // moved back in its place. In the editor process's environment, so it holds across script reloads
        const string HoldMoveVariable = "AUTOPILOT_HOLD_SETTINGS_MOVE";

        /// <summary>Hold (or let go of) the move of the settings folder from its old name, MoveSettings.</summary>
        public static void HoldSettingsMove(bool hold)
        {
            Environment.SetEnvironmentVariable(HoldMoveVariable, hold ? "1" : null);
        }

        /// <summary>
        /// The settings folder under its old name moved to Autopilot/ in <paramref name="settingsFolder"/>, when there is
        /// no Autopilot/ yet: renamed, or copied when a file in it is in use (an agent service from before still
        /// running); then its gamer.env becomes autopilot.env, its GAMER_* keys AUTOPILOT_*. The agent service
        /// (autopilot/bridge.py) and the other plugins do the same, whichever starts first.
        /// </summary>
        public static void MoveSettings(string settingsFolder)
        {
            if (Environment.GetEnvironmentVariable(HoldMoveVariable) == "1") return;
            var to = Path.Combine(settingsFolder, FolderName);
            var from = Path.Combine(settingsFolder, OldFolderName);
            try
            {
                if (!Directory.Exists(to) && !File.Exists(to) && Directory.Exists(from))
                {
                    try
                    {
                        Directory.Move(from, to);
                    }
                    catch (Exception)
                    {
                        CopyFolder(from, to);
                    }
                }
                var oldEnv = Path.Combine(to, OldEnvFile);
                var newEnv = Path.Combine(to, AutopilotEnv.FileName);
                if (File.Exists(oldEnv) && !File.Exists(newEnv))
                {
                    File.WriteAllText(newEnv, OldEnvKey.Replace(File.ReadAllText(oldEnv), "$1AUTOPILOT_"));
                    Files.OwnerOnly(newEnv);
                    File.Delete(oldEnv);
                }
            }
            catch (Exception)
            {
                // (left as it is: the next start tries again)
            }
        }

        static void CopyFolder(string from, string to)
        {
            Directory.CreateDirectory(to);
            foreach (var file in Directory.GetFiles(from))
            {
                try
                {
                    File.Copy(file, Path.Combine(to, Path.GetFileName(file)), false);
                }
                catch (Exception)
                {
                    // (in use, or there already: the rest is copied)
                }
            }
            foreach (var dir in Directory.GetDirectories(from)) CopyFolder(dir, Path.Combine(to, Path.GetFileName(dir)));
        }

        /// <summary>
        /// The address a running agent service wrote to Autopilot/<paramref name="file"/>; null when none did, the one
        /// that did has ended, or it names anything but this machine.
        /// </summary>
        public static string AnnouncedUrl(string file) => Announced(file, out _);

        /// <summary>As AnnouncedUrl, with the process id the file names (0 when there is no url).</summary>
        public static string Announced(string file, out int pid)
        {
            pid = 0;
            try
            {
                var path = Path.Combine(Folder(), file);
                if (!File.Exists(path)) return null;
                var url = ParseAnnouncement(File.ReadAllText(path), out var said);
                if (url == null || !Running(said)) return null;
                pid = said;
                return url;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>A brain.json's url and pid ({"url", "pid", "started"}); null when it names no url on this machine
        /// or no process.</summary>
        public static string ParseAnnouncement(string text, out int pid)
        {
            pid = 0;
            try
            {
                if (!(Json.Parse(text ?? "") is Dictionary<string, object> said)) return null;
                var url = Json.Str(said, "url");
                var p = (int)Json.Num(said, "pid", 0);
                if (string.IsNullOrEmpty(url) || p <= 0) return null;
                if (!url.StartsWith("ws://127.0.0.1:") && !url.StartsWith("ws://localhost:")) return null;
                pid = p;
                return url;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>Whether the process <paramref name="pid"/> runs.</summary>
        public static bool Running(int pid)
        {
            try
            {
                using (var p = Process.GetProcessById(pid)) return !p.HasExited;
            }
            catch (Exception)
            {
                return false;  // (no such process)
            }
        }

        /// <summary>The agent service the Aura app runs; null when it isn't running.</summary>
        public static string ServiceUrl() => AnnouncedUrl(AuraBrainFile);

        /// <summary>The Aura app, where its installer puts it; null when it isn't there.</summary>
        public static string AppPath()
        {
            var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var local = Environment.GetEnvironmentVariable("LOCALAPPDATA") ?? Path.Combine(home, "AppData", "Local");
                var exe = Path.Combine(local, "Programs", "aura-client", "Aura.exe");
                return File.Exists(exe) ? exe : null;
            }
            foreach (var app in new[] { "/Applications/Aura.app", Path.Combine(home, "Applications", "Aura.app") })
                if (Directory.Exists(app)) return app;
            return null;
        }

        /// <summary>Whether Aura is on this machine (its app is installed).</summary>
        public static bool IsInstalled() => InstalledOverride ?? AppPath() != null;

        /// <summary>Tests: whether the Aura app counts as installed (null: as it is).</summary>
        public static bool? InstalledOverride;

        /// <summary>Start the Aura app (it starts its agent service). Returns whether it was started.</summary>
        public static bool Launch()
        {
            var app = AppPath();
            if (app == null) return false;
            try
            {
                var info = app.EndsWith(".app")
                    ? new ProcessStartInfo("/usr/bin/open", "\"" + app + "\"")
                    : new ProcessStartInfo(app);
                info.UseShellExecute = false;
                using (Process.Start(info)) return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
